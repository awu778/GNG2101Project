﻿using System.Windows.Forms;

namespace GAVPI
{
    public partial class frm_AddEdit_LogicalTrigger : Form
    {
        public frm_AddEdit_LogicalTrigger()
        {
            InitializeComponent();
        }
    }
}
