﻿using GAVPI.GUI.Info;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace GAVPI
{
    public partial class frmGAVPI : Form
    {
        private readonly Color uiNormalColor = Color.SeaShell;
        private readonly Color uiActiveColor = Color.PowderBlue;

        private List<PSTool> psTools;
        private List<String> keyPressHistory;

        private readonly Dictionary<String, String> helperKeys = new Dictionary<string, string>
        {
            {"RControlKey", "Ctrl"},
            {"LControlKey", "Ctrl"}
        };


        public frmGAVPI()
        {

            InitializeComponent();

            this.keyPressHistory = new List<String>();

            //initialise tools: move, lasso select, quick select, zoom in, zoom out, brush, pen, pencil, bucket, eraser
            //text, new file, save file, undo, redo, previous brush, next brush, brush size up, brush size down, pick colour
            psTools = new List<PSTool> {
                new PSTool(1, "B", "brush", brushButton),
                new PSTool(2, "V", "move", moveButton),
                new PSTool(3, "L", "lasso", lassoButton),
                new PSTool(4, "C", "crop", cropButton),
                new PSTool(5, "Ctrl Oemplus", "zoom in", zoomInButton),
                new PSTool(6, "Ctrl OemMinus", "zoom out", zoomOutButton),
                new PSTool(7, "P", "pen", penButton),
                new PSTool(8, "K", "bucket", bucketButton),
                new PSTool(9, "E", "eraser", eraserButton),
                new PSTool(10, "T", "text", textButton),
                new PSTool(11, "Ctrl N", "new file", newFileButton),
                new PSTool(12, "Ctrl S", "save", saveFileButton),
                new PSTool(13, "Ctrl Z", "undo", undoButton),
                new PSTool(14, "Ctrl Y", "redo", redoButton),
                new PSTool(15, "Oemcomma", "previous brush", prevBrushButton),
                new PSTool(16, "OemPeriod", "next brush", nextBrushButton),
                new PSTool(17, "OemOpenBrackets", "decrease size", brushSizeDecButton),
                new PSTool(18, "Oem6", "increase size", brushSizeIncButton),
                new PSTool(19, "N", "color menu", pickColourButton)
            };

        }
        #region Main form

        //
        //  private void frmGAVPI_Activated( object, System.EventArgs )
        //
        //  Handling Activated events upon a Form offers the opportunty of a callback whenever the Form gains
        //  focus.
        //

        private void frmGAVPI_Activated(object sender, System.EventArgs e)
        {

            RefreshUI(null);

        }  //  private void frmGAVPI_Activated( object, System.EventArgs )

        
        //
        //  loadToolStripMenuItem_Click()
        //
        //  A handler for the Load Profile menu item in the File menu, allowing the user to select an existing
        //  Binding Definition Profile.  The Binding Definition Profile may be edited and saved within frmProfile.
        //

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {

            //  If we're Listening for voice commands, stop Listening since we may be about to open another Profile...

            if (GAVPI.vi.IsListening) btnMainListen_Click(sender, e);

            //  Attempt to open a Profile and, if successful, enable the Listen button and the Profile->Modify
            //  menu item (these items should both be disabled in the absense of a loaded Profile during
            //  the frmGAVPI_Activated event handler).

            if (GAVPI.LoadProfile())
            {
                btnMainListen.Enabled = true;
                editToolStripMenuItem.Enabled = true;
            }

            //  Maintain a consistent Form status...
            btmStripStatus.Text = GAVPI.GetStatusString();

            return;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GAVPI.Exit();
        }

        #endregion
        #region Profile

        // New Profile
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Exactly like modify, except we warn the user to save their current profile
            // before creating a new one.

            if (!GAVPI.NewProfile()) return;

            //  Refer to our general Profile editing handler...

            modifyToolStripMenuItem_Click(sender, e);
        }

        // Modify Existing
        private void modifyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                GAVPI.OpenProfileEditor(sender, e);

                //  Enable both the Listen button and the Profile->Modify menu item if the current Profile is populated.

                if (GAVPI.Profile.IsEmpty()) return;

                btnMainListen.Enabled = true;
                editToolStripMenuItem.Enabled = true;

                //
                //  Profile takes care of tracking changes and the saved/unsaved state of the current Profile.
                //  We can act on this knowledge to update the status in the UI and also inform the user of those
                //  unsaved changes should they choose a potentially destructive act (exiting the program, opening
                //  an existing Profile).
                //

                btmStripStatus.Text = GAVPI.GetStatusString();

            }
            catch (Exception profile_exception)
            {
                MessageBox.Show("Profile Editor Crashed.\n" + profile_exception.Message, "Error",
                   MessageBoxButtons.OK,
                   MessageBoxIcon.Exclamation,
                   MessageBoxDefaultButton.Button1);

                GAVPI.Profile.NewProfile();
            }

        }  //  private void modifyToolStripMenuItem_Click( object, EventArgs )

        #endregion
        #region Settings
        private void mainStripSettings_Click(object sender, EventArgs e)
        {
            GAVPI.OpenSettings(sender, e);
        }
        #endregion

        private void btnMainListen_Click(object sender, EventArgs e)
        {
            foreach (PSTool psTool in this.psTools)
            {
                ShowButtonInactive(psTool.button);
            }

            GAVPI.ToggleVoiceListening(sender, e);
        }

        public void ShowActiveButtonFromCommand(string command)
        {
            foreach (PSTool psTool in this.psTools)
            {
                if (psTool.name.Equals(command))
                {
                    ShowButtonActive(psTool.button);
                }
                else
                {
                    ShowButtonInactive(psTool.button);
                }
            }
        }

        public void ShowActiveButtonFromKey(String key)
        {
            this.keyPressHistory.Add(key);

            if (keyPressHistory.Count >= 2)
            {
                var previousKey = keyPressHistory[keyPressHistory.Count - 2];
                if (this.helperKeys.ContainsKey(previousKey))
                {
                    key = helperKeys[previousKey] + " " + key;
                }
            }

            //if (key.Equals("N"))
            //{
            //    Application.OpenForms[this.Name].Focus();
            //    this.launchColorPicker();
            //}

            foreach (PSTool psTool in this.psTools)
            {
                if (psTool.key.Equals(key))
                {
                    ShowButtonActive(psTool.button);
                    //psTool.button.BackColor = Color.Green;
                }
                else
                {
                    ShowButtonInactive(psTool.button);
                }
            }

        }

        public void ShowButtonActive(Button button)
        {
            button.BackColor = this.uiActiveColor;
        }

        public void ShowButtonInactive(Button button)
        {
            button.BackColor = this.uiNormalColor;
        }

        //
        //  public void RefreshUI( string )
        //
        //  Request that the User Interface updates any elements that are dependant on states that may change
        //  beyond the scope of the current thread of execution.  This method is typically called by way of the GAVPI class.
        //
        public void RefreshUI(string status)
        {
            //  Ensure the log is updated to reflect any additional entries and move to the last log item...
            var log = GAVPI.Log.ToList();
            var lastIndex = GAVPI.Log.Count() - 1;

            lstMainHearing.DataSource = log;
            //lstMainHearing.DataSource = GAVPI.Log.ToArray();
            lstMainHearing.TopIndex = lastIndex;

            if (log.Count > 0)
            {
                string currentCommand = log[lastIndex];
                ShowActiveButtonFromCommand(currentCommand);
            }

            //  The UI reflects a different workflow depending on whether it is currently listening on voice
            //  recognition commands or otherwise.

            if (GAVPI.vi.IsListening)
            {
                //btnMainStop.Enabled = true;
                //btnMainListen.Enabled = false;
                editToolStripMenuItem.Enabled = false;
            }
            else
            {
                //btnMainListen.Enabled = true;
                //btnMainStop.Enabled = false;
                editToolStripMenuItem.Enabled = true;
            }  //  if()

            //  If a Profile isn't loaded, disable Profile->Modify and the Listen button.
            if (GAVPI.Profile.IsEmpty())
            {
                btnMainListen.Enabled = false;
                editToolStripMenuItem.Enabled = false;
            }

            //  If we don't wish to update the status text, simply pass null as an argument to RefreshUI()
            if (status != null) btmStripStatus.Text = status;
            else btmStripStatus.Text = GAVPI.GetStatusString();
        }  //  public void RefreshUI( string )

        private void toggleKeyboardButton_Click(object sender, EventArgs e)
        {
            foreach (PSTool psTool in this.psTools)
            {
                ShowButtonInactive(psTool.button);
            }

            GAVPI.ToggleKeyboardListening();
        }

        public void ChangeKeyboardButtonColor(bool isActive)
        {
            foreach (PSTool psTool in this.psTools)
            {
                ShowButtonInactive(psTool.button);
            }

            if (isActive)
            {
                ShowButtonActive(toggleKeyboardButton);
            }
            else
            {
                ShowButtonInactive(toggleKeyboardButton);
            }
        }

        public void ChangeVoiceButtonColor(bool isActive)
        {
            foreach (PSTool psTool in this.psTools)
            {
                ShowButtonInactive(psTool.button);
            }

            if (isActive)
            {
                ShowButtonActive(btnMainListen);
            }
            else
            {
                ShowButtonInactive(btnMainListen);
            }
        }
    }
}
