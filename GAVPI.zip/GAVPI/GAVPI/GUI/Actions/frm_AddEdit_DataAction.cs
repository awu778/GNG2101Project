﻿using System.Windows.Forms;

namespace GAVPI
{
    public partial class frm_AddEdit_DataAction : Form
    {
        public frm_AddEdit_DataAction()
        {
            InitializeComponent();
        }
    }
}
