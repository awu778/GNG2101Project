﻿using System.Windows.Forms;

namespace GAVPI.GUI.Template
{
    public partial class frm_AddEdit_TemplateAction : Form
    {
        public frm_AddEdit_TemplateAction()
        {
            InitializeComponent();
        }
    }
}
