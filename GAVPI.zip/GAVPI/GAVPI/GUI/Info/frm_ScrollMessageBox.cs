﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace GAVPI.GUI.Info
{
    public partial class frm_ScrollMessageBox : Form
    {
        public frm_ScrollMessageBox(List<string> info)
        {
            InitializeComponent();
            lstboxInfo.DataSource = info;
        }
    }
}
