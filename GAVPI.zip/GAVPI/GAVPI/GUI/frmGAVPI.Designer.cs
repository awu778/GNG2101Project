﻿namespace GAVPI
{
    partial class frmGAVPI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGAVPI));
            this.mainStatStrip = new System.Windows.Forms.StatusStrip();
            this.btmStripStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mainStripFile = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainStripProfile = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainStripSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.lstMainHearing = new System.Windows.Forms.ListBox();
            this.RecognizedColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnMainListen = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lassoButton = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.saveFileButton = new System.Windows.Forms.Button();
            this.redoButton = new System.Windows.Forms.Button();
            this.newFileButton = new System.Windows.Forms.Button();
            this.brushSizeDecButton = new System.Windows.Forms.Button();
            this.undoButton = new System.Windows.Forms.Button();
            this.brushSizeIncButton = new System.Windows.Forms.Button();
            this.cropButton = new System.Windows.Forms.Button();
            this.bucketButton = new System.Windows.Forms.Button();
            this.zoomOutButton = new System.Windows.Forms.Button();
            this.nextBrushButton = new System.Windows.Forms.Button();
            this.zoomInButton = new System.Windows.Forms.Button();
            this.pickColourButton = new System.Windows.Forms.Button();
            this.prevBrushButton = new System.Windows.Forms.Button();
            this.textButton = new System.Windows.Forms.Button();
            this.moveButton = new System.Windows.Forms.Button();
            this.brushButton = new System.Windows.Forms.Button();
            this.pencilButton = new System.Windows.Forms.Button();
            this.penButton = new System.Windows.Forms.Button();
            this.eraserButton = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.toggleKeyboardButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.mainStatStrip.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainStatStrip
            // 
            this.mainStatStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btmStripStatus});
            this.mainStatStrip.Location = new System.Drawing.Point(0, 665);
            this.mainStatStrip.Name = "mainStatStrip";
            this.mainStatStrip.Size = new System.Drawing.Size(214, 22);
            this.mainStatStrip.TabIndex = 0;
            this.mainStatStrip.Text = "statusStrip1";
            // 
            // btmStripStatus
            // 
            this.btmStripStatus.Name = "btmStripStatus";
            this.btmStripStatus.Size = new System.Drawing.Size(89, 17);
            this.btmStripStatus.Text = "NOT LISTENING";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mainStripFile,
            this.mainStripProfile,
            this.mainStripSettings});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(214, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "mainMenuStrip";
            // 
            // mainStripFile
            // 
            this.mainStripFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.mainStripFile.Name = "mainStripFile";
            this.mainStripFile.Size = new System.Drawing.Size(37, 20);
            this.mainStripFile.Text = "File";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.loadToolStripMenuItem.Text = "Open Profile";
            this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // mainStripProfile
            // 
            this.mainStripProfile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.editToolStripMenuItem});
            this.mainStripProfile.Name = "mainStripProfile";
            this.mainStripProfile.Size = new System.Drawing.Size(53, 20);
            this.mainStripProfile.Text = "Profile";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.editToolStripMenuItem.Text = "Modify";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.modifyToolStripMenuItem_Click);
            // 
            // mainStripSettings
            // 
            this.mainStripSettings.Name = "mainStripSettings";
            this.mainStripSettings.Size = new System.Drawing.Size(61, 20);
            this.mainStripSettings.Text = "Settings";
            this.mainStripSettings.Click += new System.EventHandler(this.mainStripSettings_Click);
            // 
            // lstMainHearing
            // 
            this.lstMainHearing.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lstMainHearing.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lstMainHearing.Location = new System.Drawing.Point(3, 104);
            this.lstMainHearing.Name = "lstMainHearing";
            this.lstMainHearing.Size = new System.Drawing.Size(208, 41);
            this.lstMainHearing.TabIndex = 2;
            // 
            // RecognizedColumn
            // 
            this.RecognizedColumn.Text = "Recognized";
            this.RecognizedColumn.Width = 94;
            // 
            // btnMainListen
            // 
            this.btnMainListen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMainListen.Location = new System.Drawing.Point(3, 3);
            this.btnMainListen.Name = "btnMainListen";
            this.btnMainListen.Size = new System.Drawing.Size(98, 66);
            this.btnMainListen.TabIndex = 3;
            this.btnMainListen.Text = "Toggle voice listening";
            this.btnMainListen.UseVisualStyleBackColor = false;
            this.btnMainListen.Click += new System.EventHandler(this.btnMainListen_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 24);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tableLayoutPanel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tableLayoutPanel2);
            this.splitContainer1.Size = new System.Drawing.Size(214, 641);
            this.splitContainer1.SplitterDistance = 489;
            this.splitContainer1.TabIndex = 5;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.lassoButton, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.saveFileButton, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.redoButton, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.newFileButton, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.brushSizeDecButton, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.undoButton, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.brushSizeIncButton, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.cropButton, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.bucketButton, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.zoomOutButton, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.nextBrushButton, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.zoomInButton, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.pickColourButton, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.prevBrushButton, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.textButton, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.moveButton, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.brushButton, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.pencilButton, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.penButton, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.eraserButton, 1, 4);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(214, 489);
            this.tableLayoutPanel1.TabIndex = 20;
            // 
            // lassoButton
            // 
            this.lassoButton.BackColor = System.Drawing.Color.Transparent;
            this.lassoButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.lassoButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lassoButton.Enabled = false;
            this.lassoButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lassoButton.FlatAppearance.BorderSize = 0;
            this.lassoButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.lassoButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lassoButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lassoButton.ImageIndex = 6;
            this.lassoButton.ImageList = this.imageList1;
            this.lassoButton.Location = new System.Drawing.Point(107, 0);
            this.lassoButton.Margin = new System.Windows.Forms.Padding(0);
            this.lassoButton.Name = "lassoButton";
            this.lassoButton.Size = new System.Drawing.Size(107, 48);
            this.lassoButton.TabIndex = 2;
            this.lassoButton.Text = "Lasso";
            this.lassoButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lassoButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.lassoButton.UseVisualStyleBackColor = false;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "arrows-alt-solid.png");
            this.imageList1.Images.SetKeyName(1, "Brush Size Down.png");
            this.imageList1.Images.SetKeyName(2, "Brush Size Up.png");
            this.imageList1.Images.SetKeyName(3, "crop-alt-solid.png");
            this.imageList1.Images.SetKeyName(4, "eraser-pngrepo-com.png");
            this.imageList1.Images.SetKeyName(5, "fill-drip-solid.png");
            this.imageList1.Images.SetKeyName(6, "lasso-pngrepo-com.png");
            this.imageList1.Images.SetKeyName(7, "new-file-pngrepo-com.png");
            this.imageList1.Images.SetKeyName(8, "Next Brush.png");
            this.imageList1.Images.SetKeyName(9, "No Color Color Wheel.png");
            this.imageList1.Images.SetKeyName(10, "paint-brush-solid.png");
            this.imageList1.Images.SetKeyName(11, "pencil-alt-solid.png");
            this.imageList1.Images.SetKeyName(12, "pen-fancy-solid.png");
            this.imageList1.Images.SetKeyName(13, "Previous Brush.png");
            this.imageList1.Images.SetKeyName(14, "redo-alt-solid.png");
            this.imageList1.Images.SetKeyName(15, "save-regular.png");
            this.imageList1.Images.SetKeyName(16, "search-minus-solid.png");
            this.imageList1.Images.SetKeyName(17, "search-plus-solid.png");
            this.imageList1.Images.SetKeyName(18, "text-pngrepo-com.png");
            this.imageList1.Images.SetKeyName(19, "undo-alt-solid.png");
            // 
            // saveFileButton
            // 
            this.saveFileButton.BackColor = System.Drawing.Color.Transparent;
            this.saveFileButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.saveFileButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.saveFileButton.Enabled = false;
            this.saveFileButton.FlatAppearance.BorderSize = 0;
            this.saveFileButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.saveFileButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saveFileButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saveFileButton.ImageIndex = 15;
            this.saveFileButton.ImageList = this.imageList1;
            this.saveFileButton.Location = new System.Drawing.Point(107, 432);
            this.saveFileButton.Margin = new System.Windows.Forms.Padding(0);
            this.saveFileButton.Name = "saveFileButton";
            this.saveFileButton.Size = new System.Drawing.Size(107, 57);
            this.saveFileButton.TabIndex = 12;
            this.saveFileButton.Text = "Save";
            this.saveFileButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.saveFileButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.saveFileButton.UseVisualStyleBackColor = false;
            // 
            // redoButton
            // 
            this.redoButton.BackColor = System.Drawing.Color.Transparent;
            this.redoButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.redoButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.redoButton.Enabled = false;
            this.redoButton.FlatAppearance.BorderSize = 0;
            this.redoButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.redoButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.redoButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.redoButton.ImageIndex = 14;
            this.redoButton.ImageList = this.imageList1;
            this.redoButton.Location = new System.Drawing.Point(107, 384);
            this.redoButton.Margin = new System.Windows.Forms.Padding(0);
            this.redoButton.Name = "redoButton";
            this.redoButton.Size = new System.Drawing.Size(107, 48);
            this.redoButton.TabIndex = 14;
            this.redoButton.Text = "Redo";
            this.redoButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.redoButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.redoButton.UseVisualStyleBackColor = false;
            // 
            // newFileButton
            // 
            this.newFileButton.BackColor = System.Drawing.Color.Transparent;
            this.newFileButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.newFileButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.newFileButton.Enabled = false;
            this.newFileButton.FlatAppearance.BorderSize = 0;
            this.newFileButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.newFileButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newFileButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.newFileButton.ImageIndex = 7;
            this.newFileButton.ImageList = this.imageList1;
            this.newFileButton.Location = new System.Drawing.Point(0, 432);
            this.newFileButton.Margin = new System.Windows.Forms.Padding(0);
            this.newFileButton.Name = "newFileButton";
            this.newFileButton.Size = new System.Drawing.Size(107, 57);
            this.newFileButton.TabIndex = 11;
            this.newFileButton.Text = "New file";
            this.newFileButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.newFileButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.newFileButton.UseVisualStyleBackColor = false;
            // 
            // brushSizeDecButton
            // 
            this.brushSizeDecButton.BackColor = System.Drawing.Color.Transparent;
            this.brushSizeDecButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.brushSizeDecButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.brushSizeDecButton.Enabled = false;
            this.brushSizeDecButton.FlatAppearance.BorderSize = 0;
            this.brushSizeDecButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.brushSizeDecButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.brushSizeDecButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.brushSizeDecButton.ImageIndex = 1;
            this.brushSizeDecButton.ImageList = this.imageList1;
            this.brushSizeDecButton.Location = new System.Drawing.Point(107, 288);
            this.brushSizeDecButton.Margin = new System.Windows.Forms.Padding(0);
            this.brushSizeDecButton.Name = "brushSizeDecButton";
            this.brushSizeDecButton.Size = new System.Drawing.Size(107, 48);
            this.brushSizeDecButton.TabIndex = 17;
            this.brushSizeDecButton.Text = "Brush size -";
            this.brushSizeDecButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.brushSizeDecButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.brushSizeDecButton.UseVisualStyleBackColor = false;
            // 
            // undoButton
            // 
            this.undoButton.BackColor = System.Drawing.Color.Transparent;
            this.undoButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.undoButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.undoButton.Enabled = false;
            this.undoButton.FlatAppearance.BorderSize = 0;
            this.undoButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.undoButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.undoButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.undoButton.ImageIndex = 19;
            this.undoButton.ImageList = this.imageList1;
            this.undoButton.Location = new System.Drawing.Point(0, 384);
            this.undoButton.Margin = new System.Windows.Forms.Padding(0);
            this.undoButton.Name = "undoButton";
            this.undoButton.Size = new System.Drawing.Size(107, 48);
            this.undoButton.TabIndex = 13;
            this.undoButton.Text = "Undo";
            this.undoButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.undoButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.undoButton.UseVisualStyleBackColor = false;
            // 
            // brushSizeIncButton
            // 
            this.brushSizeIncButton.BackColor = System.Drawing.Color.Transparent;
            this.brushSizeIncButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.brushSizeIncButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.brushSizeIncButton.Enabled = false;
            this.brushSizeIncButton.FlatAppearance.BorderSize = 0;
            this.brushSizeIncButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.brushSizeIncButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.brushSizeIncButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.brushSizeIncButton.ImageIndex = 2;
            this.brushSizeIncButton.ImageList = this.imageList1;
            this.brushSizeIncButton.Location = new System.Drawing.Point(0, 288);
            this.brushSizeIncButton.Margin = new System.Windows.Forms.Padding(0);
            this.brushSizeIncButton.Name = "brushSizeIncButton";
            this.brushSizeIncButton.Size = new System.Drawing.Size(107, 48);
            this.brushSizeIncButton.TabIndex = 18;
            this.brushSizeIncButton.Text = "Brush size +";
            this.brushSizeIncButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.brushSizeIncButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.brushSizeIncButton.UseVisualStyleBackColor = false;
            // 
            // cropButton
            // 
            this.cropButton.BackColor = System.Drawing.Color.Transparent;
            this.cropButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.cropButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cropButton.Enabled = false;
            this.cropButton.FlatAppearance.BorderSize = 0;
            this.cropButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.cropButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cropButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cropButton.ImageIndex = 3;
            this.cropButton.ImageList = this.imageList1;
            this.cropButton.Location = new System.Drawing.Point(0, 48);
            this.cropButton.Margin = new System.Windows.Forms.Padding(0);
            this.cropButton.Name = "cropButton";
            this.cropButton.Size = new System.Drawing.Size(107, 48);
            this.cropButton.TabIndex = 3;
            this.cropButton.Text = "Crop";
            this.cropButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cropButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cropButton.UseVisualStyleBackColor = false;
            // 
            // bucketButton
            // 
            this.bucketButton.BackColor = System.Drawing.Color.Transparent;
            this.bucketButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bucketButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bucketButton.Enabled = false;
            this.bucketButton.FlatAppearance.BorderSize = 0;
            this.bucketButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.bucketButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bucketButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bucketButton.ImageIndex = 5;
            this.bucketButton.ImageList = this.imageList1;
            this.bucketButton.Location = new System.Drawing.Point(107, 48);
            this.bucketButton.Margin = new System.Windows.Forms.Padding(0);
            this.bucketButton.Name = "bucketButton";
            this.bucketButton.Size = new System.Drawing.Size(107, 48);
            this.bucketButton.TabIndex = 8;
            this.bucketButton.Text = "Bucket fill";
            this.bucketButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bucketButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bucketButton.UseVisualStyleBackColor = false;
            // 
            // zoomOutButton
            // 
            this.zoomOutButton.BackColor = System.Drawing.Color.Transparent;
            this.zoomOutButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.zoomOutButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.zoomOutButton.Enabled = false;
            this.zoomOutButton.FlatAppearance.BorderSize = 0;
            this.zoomOutButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.zoomOutButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.zoomOutButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.zoomOutButton.ImageIndex = 16;
            this.zoomOutButton.ImageList = this.imageList1;
            this.zoomOutButton.Location = new System.Drawing.Point(107, 336);
            this.zoomOutButton.Margin = new System.Windows.Forms.Padding(0);
            this.zoomOutButton.Name = "zoomOutButton";
            this.zoomOutButton.Size = new System.Drawing.Size(107, 48);
            this.zoomOutButton.TabIndex = 5;
            this.zoomOutButton.Text = "Zoom out";
            this.zoomOutButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.zoomOutButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.zoomOutButton.UseVisualStyleBackColor = false;
            // 
            // nextBrushButton
            // 
            this.nextBrushButton.BackColor = System.Drawing.Color.Transparent;
            this.nextBrushButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.nextBrushButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nextBrushButton.Enabled = false;
            this.nextBrushButton.FlatAppearance.BorderSize = 0;
            this.nextBrushButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.nextBrushButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nextBrushButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nextBrushButton.ImageIndex = 8;
            this.nextBrushButton.ImageList = this.imageList1;
            this.nextBrushButton.Location = new System.Drawing.Point(107, 240);
            this.nextBrushButton.Margin = new System.Windows.Forms.Padding(0);
            this.nextBrushButton.Name = "nextBrushButton";
            this.nextBrushButton.Size = new System.Drawing.Size(107, 48);
            this.nextBrushButton.TabIndex = 16;
            this.nextBrushButton.Text = "Next brush";
            this.nextBrushButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.nextBrushButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.nextBrushButton.UseVisualStyleBackColor = false;
            // 
            // zoomInButton
            // 
            this.zoomInButton.BackColor = System.Drawing.Color.Transparent;
            this.zoomInButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.zoomInButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.zoomInButton.Enabled = false;
            this.zoomInButton.FlatAppearance.BorderSize = 0;
            this.zoomInButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.zoomInButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.zoomInButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.zoomInButton.ImageIndex = 17;
            this.zoomInButton.ImageList = this.imageList1;
            this.zoomInButton.Location = new System.Drawing.Point(0, 336);
            this.zoomInButton.Margin = new System.Windows.Forms.Padding(0);
            this.zoomInButton.Name = "zoomInButton";
            this.zoomInButton.Size = new System.Drawing.Size(107, 48);
            this.zoomInButton.TabIndex = 4;
            this.zoomInButton.Text = "Zoom in";
            this.zoomInButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.zoomInButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.zoomInButton.UseVisualStyleBackColor = false;
            // 
            // pickColourButton
            // 
            this.pickColourButton.BackColor = System.Drawing.Color.Transparent;
            this.pickColourButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pickColourButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pickColourButton.Enabled = false;
            this.pickColourButton.FlatAppearance.BorderSize = 0;
            this.pickColourButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.pickColourButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pickColourButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.pickColourButton.ImageIndex = 9;
            this.pickColourButton.ImageList = this.imageList1;
            this.pickColourButton.Location = new System.Drawing.Point(0, 0);
            this.pickColourButton.Margin = new System.Windows.Forms.Padding(0);
            this.pickColourButton.Name = "pickColourButton";
            this.pickColourButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.pickColourButton.Size = new System.Drawing.Size(107, 48);
            this.pickColourButton.TabIndex = 19;
            this.pickColourButton.Text = "Colour";
            this.pickColourButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.pickColourButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.pickColourButton.UseVisualStyleBackColor = false;
            // 
            // prevBrushButton
            // 
            this.prevBrushButton.BackColor = System.Drawing.Color.Transparent;
            this.prevBrushButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.prevBrushButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.prevBrushButton.Enabled = false;
            this.prevBrushButton.FlatAppearance.BorderSize = 0;
            this.prevBrushButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.prevBrushButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.prevBrushButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.prevBrushButton.ImageIndex = 13;
            this.prevBrushButton.ImageList = this.imageList1;
            this.prevBrushButton.Location = new System.Drawing.Point(0, 240);
            this.prevBrushButton.Margin = new System.Windows.Forms.Padding(0);
            this.prevBrushButton.Name = "prevBrushButton";
            this.prevBrushButton.Size = new System.Drawing.Size(107, 48);
            this.prevBrushButton.TabIndex = 15;
            this.prevBrushButton.Text = "Prev. brush";
            this.prevBrushButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.prevBrushButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.prevBrushButton.UseVisualStyleBackColor = false;
            // 
            // textButton
            // 
            this.textButton.BackColor = System.Drawing.Color.Transparent;
            this.textButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.textButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textButton.Enabled = false;
            this.textButton.FlatAppearance.BorderSize = 0;
            this.textButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.textButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.textButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.textButton.ImageIndex = 18;
            this.textButton.ImageList = this.imageList1;
            this.textButton.Location = new System.Drawing.Point(0, 96);
            this.textButton.Margin = new System.Windows.Forms.Padding(0);
            this.textButton.Name = "textButton";
            this.textButton.Size = new System.Drawing.Size(107, 48);
            this.textButton.TabIndex = 10;
            this.textButton.Text = "Text";
            this.textButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.textButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.textButton.UseVisualStyleBackColor = false;
            // 
            // moveButton
            // 
            this.moveButton.BackColor = System.Drawing.Color.Transparent;
            this.moveButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.moveButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.moveButton.Enabled = false;
            this.moveButton.FlatAppearance.BorderSize = 0;
            this.moveButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.moveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.moveButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.moveButton.ImageIndex = 0;
            this.moveButton.ImageList = this.imageList1;
            this.moveButton.Location = new System.Drawing.Point(107, 96);
            this.moveButton.Margin = new System.Windows.Forms.Padding(0);
            this.moveButton.Name = "moveButton";
            this.moveButton.Size = new System.Drawing.Size(107, 48);
            this.moveButton.TabIndex = 1;
            this.moveButton.Text = "Move";
            this.moveButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.moveButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.moveButton.UseVisualStyleBackColor = false;
            // 
            // brushButton
            // 
            this.brushButton.BackColor = System.Drawing.Color.Transparent;
            this.brushButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.brushButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.brushButton.Enabled = false;
            this.brushButton.FlatAppearance.BorderSize = 0;
            this.brushButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.brushButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.brushButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.brushButton.ImageIndex = 10;
            this.brushButton.ImageList = this.imageList1;
            this.brushButton.Location = new System.Drawing.Point(0, 144);
            this.brushButton.Margin = new System.Windows.Forms.Padding(0);
            this.brushButton.Name = "brushButton";
            this.brushButton.Size = new System.Drawing.Size(107, 48);
            this.brushButton.TabIndex = 0;
            this.brushButton.Text = "Brush";
            this.brushButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.brushButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.brushButton.UseVisualStyleBackColor = false;
            // 
            // pencilButton
            // 
            this.pencilButton.BackColor = System.Drawing.Color.Transparent;
            this.pencilButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pencilButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pencilButton.Enabled = false;
            this.pencilButton.FlatAppearance.BorderSize = 0;
            this.pencilButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.pencilButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pencilButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.pencilButton.ImageIndex = 11;
            this.pencilButton.ImageList = this.imageList1;
            this.pencilButton.Location = new System.Drawing.Point(107, 144);
            this.pencilButton.Margin = new System.Windows.Forms.Padding(0);
            this.pencilButton.Name = "pencilButton";
            this.pencilButton.Size = new System.Drawing.Size(107, 48);
            this.pencilButton.TabIndex = 7;
            this.pencilButton.Text = "Pencil";
            this.pencilButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.pencilButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.pencilButton.UseVisualStyleBackColor = false;
            // 
            // penButton
            // 
            this.penButton.BackColor = System.Drawing.Color.Transparent;
            this.penButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.penButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.penButton.Enabled = false;
            this.penButton.FlatAppearance.BorderSize = 0;
            this.penButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.penButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.penButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.penButton.ImageIndex = 12;
            this.penButton.ImageList = this.imageList1;
            this.penButton.Location = new System.Drawing.Point(0, 192);
            this.penButton.Margin = new System.Windows.Forms.Padding(0);
            this.penButton.Name = "penButton";
            this.penButton.Size = new System.Drawing.Size(107, 48);
            this.penButton.TabIndex = 6;
            this.penButton.Text = "Pen";
            this.penButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.penButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.penButton.UseVisualStyleBackColor = false;
            // 
            // eraserButton
            // 
            this.eraserButton.BackColor = System.Drawing.Color.Transparent;
            this.eraserButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.eraserButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.eraserButton.Enabled = false;
            this.eraserButton.FlatAppearance.BorderSize = 0;
            this.eraserButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.eraserButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.eraserButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.eraserButton.ImageIndex = 4;
            this.eraserButton.ImageList = this.imageList1;
            this.eraserButton.Location = new System.Drawing.Point(107, 192);
            this.eraserButton.Margin = new System.Windows.Forms.Padding(0);
            this.eraserButton.Name = "eraserButton";
            this.eraserButton.Size = new System.Drawing.Size(107, 48);
            this.eraserButton.TabIndex = 9;
            this.eraserButton.Text = "Eraser";
            this.eraserButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.eraserButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.eraserButton.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.lstMainHearing, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(214, 148);
            this.tableLayoutPanel2.TabIndex = 7;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.btnMainListen, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.toggleKeyboardButton, 1, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(208, 72);
            this.tableLayoutPanel3.TabIndex = 6;
            // 
            // toggleKeyboardButton
            // 
            this.toggleKeyboardButton.BackColor = System.Drawing.Color.SeaShell;
            this.toggleKeyboardButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toggleKeyboardButton.Location = new System.Drawing.Point(107, 3);
            this.toggleKeyboardButton.Name = "toggleKeyboardButton";
            this.toggleKeyboardButton.Size = new System.Drawing.Size(98, 66);
            this.toggleKeyboardButton.TabIndex = 6;
            this.toggleKeyboardButton.Text = "Toggle keyboard listening";
            this.toggleKeyboardButton.UseVisualStyleBackColor = false;
            this.toggleKeyboardButton.Click += new System.EventHandler(this.toggleKeyboardButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Voice history";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmGAVPI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(214, 687);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.mainStatStrip);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(230, 726);
            this.Name = "frmGAVPI";
            this.Text = "HELPO";
            this.Activated += new System.EventHandler(this.frmGAVPI_Activated);
            this.mainStatStrip.ResumeLayout(false);
            this.mainStatStrip.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip mainStatStrip;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mainStripFile;
		private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mainStripSettings;
        private System.Windows.Forms.ToolStripMenuItem mainStripProfile;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ListBox lstMainHearing;
        private System.Windows.Forms.Button btnMainListen;
        private System.Windows.Forms.ColumnHeader RecognizedColumn;
        private System.Windows.Forms.ToolStripStatusLabel btmStripStatus;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button brushButton;
        private System.Windows.Forms.Button moveButton;
        private System.Windows.Forms.Button pickColourButton;
        private System.Windows.Forms.Button brushSizeIncButton;
        private System.Windows.Forms.Button brushSizeDecButton;
        private System.Windows.Forms.Button nextBrushButton;
        private System.Windows.Forms.Button prevBrushButton;
        private System.Windows.Forms.Button redoButton;
        private System.Windows.Forms.Button undoButton;
        private System.Windows.Forms.Button saveFileButton;
        private System.Windows.Forms.Button newFileButton;
        private System.Windows.Forms.Button textButton;
        private System.Windows.Forms.Button eraserButton;
        private System.Windows.Forms.Button bucketButton;
        private System.Windows.Forms.Button pencilButton;
        private System.Windows.Forms.Button penButton;
        private System.Windows.Forms.Button zoomOutButton;
        private System.Windows.Forms.Button zoomInButton;
        private System.Windows.Forms.Button cropButton;
        private System.Windows.Forms.Button lassoButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button toggleKeyboardButton;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
    }
}

