﻿Helpo - Your Photoshop Assistant

This app is built as a modification of GAVPI, which is an open-source project (https://github.com/baykovr/AVPI)

The following icons used in this application are used with a public license from FontAwesome with no modification (https://fontawesome.com/license):
Move, crop, zoom in, zoom out, brush, pen, pencil, bucket, save file, undo, redo.