﻿namespace GAVPI
{
    public interface Trigger_Event
    {
        string name { get; set; }
        string type { get; set; }
        string comment { get; set; }
        string value { get; set; }
        void run();
    }
}
