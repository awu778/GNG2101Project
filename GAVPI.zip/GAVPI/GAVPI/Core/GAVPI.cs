﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using TrivialLogging;
using TrivialMRUMenu;
using TrivialProcessMonitor;

namespace GAVPI
{
    static class GAVPI
    {

        //  The application's title, a system-wide unique ID to facilitate single-instancing (see Mutex,
        //  later), and an XML Path to easily extract specific information from GAVPI Profile XML documents.

        public const string BUILD_VERSION = "HELPO 1.3";
        const string APPLICATION_TITLE = "HELPO";
        const string APPLICATION_ID = "Global\\" + "{c3ab185c-d7f7-4bf9-bc81-0f0e93d52ac3}";
        const string ASSOCIATED_PROCESS_XML_PATH = "/gavpi/AssociatedProcess";

        //  The application global configuration settings, voice recognition grammar and voice recognition engine.

        public static Settings Settings;
        public static Profile Profile;

        public static InputEngine vi;

        private static frmGAVPI MainForm;
        private static frmProfile ProfileEditor;
        private static frmSettings SettingsForm;

        //  Our running Log and the Most Recently Used Profile list.
        public static Logging<string> Log;

        //  Profile loading/unload debug log.
        public static Logging<string> ProfileDebugLog;

        private static Dictionary<string, string> AssociatedProfiles = new Dictionary<string, string>();

        //  We maintain a system tray icon and context menu...

        //public static NotifyIcon sysTrayIcon;
        //private static ContextMenu sysTrayMenu;
        public static bool IsFirstClose = true; //is this the first time the main window has been closed

        //  Our system tray context menu items are declared for convenience.  If we add or remove items at some
        //  point, let's reflect that here.

        private static int OPEN_PROFILE_MENU_ITEM = 1;
        private static int MODIFY_PROFILE_MENU_ITEM = 2;
        private static int OPEN_LOG_MENU_ITEM = 4;
        private static int LISTEN_MENU_ITEM = 6;
        private static int STOP_LISTENING_MENU_ITEM = 7;
        private static int OPEN_SETTINGS_MENU_ITEM = 8;

        private const int WH_KEYBOARD_LL = 13;
        private const int WM_KEYDOWN = 0x0100;
        private static LowLevelKeyboardProc _proc = HookCallback;
        private static IntPtr _hookID = IntPtr.Zero;
        private static bool keyboardListening = false;
        private static bool voiceListening = false;

        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int idHook,
        LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode,
            IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            //  Instantiate a log that maintains a running record of the recognised voice commands.  This log
            //  will be displayed within a ListBox in the main form, frmGAVPI.  We specify a callback method so
            //  that we may inform an already open frmGAVPI to update the ListBox with the log content.

            // Additionally we maintain of a log of profile loading/saving information.
            try
            {
                Log = new Logging<string>(GAVPI.OnLogMessage);
                ProfileDebugLog = new Logging<string>();
                            }
            catch (Exception) { throw; }

            _hookID = SetHook(_proc);

            Settings = new Settings();
            Profile = new Profile("./Helpo.XML");
            //LoadProfile("Helpo.XML");

            vi = new InputEngine();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            //
            //  To ensure that only a single instance of the application can be executed at a time, we'll use
            //  Mutex ownership to determine if we're already running.  I used http://www.guidgenerator.com/
            //  to create a Globally Unique ID (GUID) as the name of a Mutex, which the application will attempt
            //  to secure before running proper.  If the Mutex can't be secured it means our application is
            //  already running.
            //

            Mutex LockApplicationInstance;
            bool OnlyApplicationInstance = false;

           
            OpenMainWindow(null, null);

            Application.Run();

            UnhookWindowsHookEx(_hookID);
        }  //  static void Main()

        private static IntPtr SetHook(LowLevelKeyboardProc proc)
        {
            using (Process curProcess = Process.GetCurrentProcess())
            using (ProcessModule curModule = curProcess.MainModule)
            {
                return SetWindowsHookEx(WH_KEYBOARD_LL, proc,
                    GetModuleHandle(curModule.ModuleName), 0);
            }
        }

        public static void ToggleKeyboardListening()
        {
            keyboardListening = !keyboardListening;
            MainForm.ChangeKeyboardButtonColor(keyboardListening);
        }

        public static void ToggleVoiceListening(object sender, EventArgs e)
        {
            voiceListening = !voiceListening;
            MainForm.ChangeVoiceButtonColor(voiceListening);
            if (voiceListening)
            {
                StartListening(sender, e);
            }
            else if (!voiceListening)
            {
                StopListening(sender, e);
            }
        }

        private static IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (keyboardListening)
            {
                if (nCode >= 0 && wParam == (IntPtr)WM_KEYDOWN)
                {
                    int vkCode = Marshal.ReadInt32(lParam);
                    Console.WriteLine((Keys)vkCode);

                    Keys vkcodeAsKeys = (Keys)vkCode;
                    string key = vkcodeAsKeys.ToString();

                    MainForm.ShowActiveButtonFromKey(key);
                }
            }

            return CallNextHookEx(_hookID, nCode, wParam, lParam);
        }


        //
        //  static private void Exit( object, EventArgs )
        //
        //  Our application exit routine, conveniently wrapped up in an event handler object (making it idea
        //  for calling from a UI element).
        //
        static public void Exit()
        {

            if (Profile.IsEdited()) NotifyUnsavedChanges();

            //  And persist any of the settings.
            Properties.Settings.Default.Save();

            // Stop listening.
            StopListening(null, null);

            Application.Exit();
        }  //  static private void Exit( object, EventArgs )

        //
        //  static public void OnLogMessage( string )
        //
        //  Our logging class accepts OnLogMessage as a callback function, where we request that frmGAVPI update
        //  the ListBox displaying the log content - via a call to frmGAVPI.RefreshUI().
        //
        static public void OnLogMessage(string loggedMessage)
        {
            if (Application.OpenForms.OfType<frmGAVPI>().Count() > 0) MainForm.RefreshUI(null);
        }  //  static public void OnLogMessage( string )

        //
        //  static public string GetStatusString()
        //
        //  Build a string based on the state of the voice recognition engine, the loaded profile and its
        //  edited state.  This string is typically displayed within the status bar of prominent forms, like
        //  frmGAVPI and frmProfile.
        //
        static public string GetStatusString()
        {

            return (vi.IsListening ? "LISTENING:" : "NOT LISTENING:") + " " +
                   (Profile.IsEdited() ? " [UNSAVED] " : " ") +
                   Path.GetFileNameWithoutExtension(Profile.GetProfileFilename());

        }  //  static public string GetStatusString()

        //
        //  static public void StartListening()
        //
        //  StartListening() attempts to establish command recognition.
        //
        static public void StartListening(object SelectedMenuItem, EventArgs e)
        {
            //  If we're not already listening on voice commands, try to start listening (this is a sanity
            //  check that we shouldn't need, but to hell with it)...

            if (vi.IsListening || !vi.load_listen()) return;

            //  Update the main form's UI to reflect the listening state.

            if (Application.OpenForms.OfType<frmGAVPI>().Count() > 0)
                MainForm.RefreshUI(GetStatusString());      

        }  //  static public void StartListening()

        //
        //  static public void StopListening()
        //
        //  Typically called via the user interface, StopListening() requests that the voice recognition engine
        //  stops listening for spoken commands.
        //
        static public void StopListening(object SelectedMenuItem, EventArgs e)
        {

            if (!vi.IsListening) return;

            //  Stop listening on voice commands...

            vi.stop_listen();
            vi = new InputEngine();

            //  Update the main form to reflect the stopped state...

            if (Application.OpenForms.OfType<frmGAVPI>().Count() > 0)
                MainForm.RefreshUI(GetStatusString());
        }  //  static public void StopListening()


        //
        //  static public void OpenMainWindow( object, EventArgs )
        //
        //  A convenient sanity-checking method for opening the main window.
        //
        static public void OpenMainWindow(object SelectedMenuItem, EventArgs e)
        {

            MainForm = new frmGAVPI();

            if (MainForm == null) return;

            MainForm.ShowDialog();

        }  //  static public void OpenMainWindow( object, EventArgs )


        //
        //  static public void OpenProfileEditor
        //
        //  This method is the prefered way of instantiating the Profile editing form, frmProfile.
        //
        static public void OpenProfileEditor(object SelectedMenuItem, EventArgs e)
        {
            ProfileEditor = new frmProfile();

            if (ProfileEditor == null) return;

            //  For now, at least, stop listening if the Profile is in danger of being edited.

            StopListening(null, null);

            ProfileEditor.ShowDialog();

            CloseProfileEditor();

            return;

        }  //  static public void OpenProfileEditor



        //
        //  static public void CloseProfileEditor()
        //
        //  CloseProfileEditor is the sanity-checking prefered way of closing the Profile editor form
        //  (frmProfile) when opened via OpenProfileEditor().
        //
        static public void CloseProfileEditor()
        {

            if (ProfileEditor == null) return;

            ProfileEditor.Dispose();

            ProfileEditor = null;

        }  //  static public void CloseProfileEditor()

        //
        //  static private void OpenSettings()
        //
        //  Open the Settings window.
        //

        static public void OpenSettings(object SelectedMenuItem, EventArgs e)
        {
            //  If the Settings form is already open, bring it to the front...
            if (Application.OpenForms.OfType<frmSettings>().Count() > 0)
            {
                SettingsForm.TopMost = true;
                return;
            }  //  if()

            SettingsForm = new frmSettings(Settings);

            SettingsForm.ShowDialog();

        }  //  static private void OpenSettings()


        //
        //  static private bool NotifyUnsavedChanges()
        //
        //  NotifyUnsavedChanges is employed by any method that acts destructively on an existing Profile with
        //  unsaved edits, prompting the user to persist the Profile.
        //
        static private bool NotifyUnsavedChanges()
        {

            DialogResult SaveChanges = MessageBox.Show("It appears you have made changes to your Profile.\n\n" +
                                                        "Would you like to save those changes now?",
                                                        "Unsaved Profile",
                                                        MessageBoxButtons.YesNo);

            if (SaveChanges == DialogResult.Yes)
            {

                if (Profile.GetProfileFilename() == null && !SaveAsProfile()) return false;
                else if (!SaveProfile()) return false;

            }  //  if()

            return true;

        }  //  static private bool NotifyUnsavedChanges()



        //
        //  static public bool LoadProfile()
        //
        //  A convenient centralised method returning boolean success or failure, LoadProfile directs Profile
        //  to read a Profile from disk while ensuring that any currently open form reflects the opened Profile
        //  status in its UI.  This method considers whether a currently open Profile has unsaved edits, offering
        //  the opportunity to persist the Profile.
        //
        //  LoadProfile returns boolean success or failure.
        //
        static public bool LoadProfile(string filename)
        {

            //  Offer to persist any unsaved Profile edits...

            if (Profile.IsEdited() && NotifyUnsavedChanges() == false) return false;

            //  Present the user with a File Open Dialog through which they may choose a Profile to load.

            if (filename == null) using (OpenFileDialog profile_dialog = new OpenFileDialog())
                {

                    //  Give the Dialog a title and then establish a filter to hide anything that isn't an XML
                    //  file by default.

                    profile_dialog.Title = "Select a Profile to open";
                    profile_dialog.Filter = "Profiles (*.XML)|*.XML|All Files (*.*)|*.*";

                    //  Try get the path to a directory within GAVPI's own directory called "Profiles", and make that
                    //  the default directory in the OpenFileDialog.

                    string GAVPIPath = new Uri(System.IO.Path.GetDirectoryName(
                        System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)).LocalPath;

                    if (Directory.Exists(GAVPIPath + "\\Profiles")) GAVPIPath += "\\Profiles";

                    profile_dialog.InitialDirectory = GAVPIPath;

                    if (profile_dialog.ShowDialog() == DialogResult.Cancel) return false;

                    //  Save the loaded Profile's filename for convenience sake.

                    filename = profile_dialog.FileName;

                }  //  if()... using()...

            //  Attempt to load the given Profile...

            if (!Profile.load_profile(filename))
            {

                MessageBox.Show("There appears to be a problem with the Profile you have chosen.\n\n" +
                                 "The Profile may have been moved or deleted, or it may not be an\n" +
                                 "actual Profile. It may even have become corrupted. Please check\n" +
                                 "the Profile by attempting to open it in the Profile Editor.",
                                 "I cannot open the Profile",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Exclamation,
                                 MessageBoxDefaultButton.Button1);

                return false;

            }  //  if()

            //  Clear the log before requesting frmGAVPI refresh its UI otherwise the ListBox may remain
            //  populated.

            Log.Clear();

            if (Application.OpenForms.OfType<frmGAVPI>().Count() > 0)
                MainForm.RefreshUI(GetStatusString());

            if (Application.OpenForms.OfType<frmProfile>().Count() > 0)
                ProfileEditor.RefreshUI(GetStatusString());

            return true;

        }  //  static public bool LoadProfile()


        //
        //  static public void LoadProfile( object, EventArgs )
        //
        //  An overloaded instance of LoadProfile( string ), suitable as a menu item click handler.
        //
        static public void LoadProfile(object SelectedMenuItem, EventArgs e)
        {
            LoadProfile(null);
        }  //  static public void LoadProfile( object, EventArgs )

        //
        //  static public bool LoadProfile()
        //
        //  An overloaded instance of LoadProfile( string ) ideally suited for untargetted Profile loading.
        //

        static public bool LoadProfile()
        {
            return LoadProfile(null);
        }  //  static public bool LoadProfile()


        //
        //  static public bool SaveAsProfile()
        //
        //  Assuming an existing Profile hasn't been previously saved, query the user for a filename then save
        //  the Profile.  Returns a boolean value denoting success or failure.
        //
        //  This method should be used instead of Profile.save_profile which will become DEPRECIATED.
        //

        static public bool SaveAsProfile()
        {

            if (Profile.IsEmpty()) return false;

            using (SaveFileDialog dialog = new SaveFileDialog())
            {

                //  Give the Dialog a title then establish a default filter to hide anything that isn't an XML
                //  file.

                dialog.Title = "Save your Profile as...";
                dialog.Filter = "Profiles (*.XML)|*.XML|All Files (*.*)|*.*";

                dialog.RestoreDirectory = true;

                if (dialog.ShowDialog() == DialogResult.Cancel) return false;

                return Profile.save_profile(dialog.FileName) ? true : false;

            }  //  using()           

        }  //  static public bool SaveAsProfile()


        //
        //  static public bool SaveProfile()
        //
        //  Save the Profile as maintained by Profile to the existing filename maintained within Profile.
        //  Returns a boolean value denoting success or failure.
        //
        static public bool SaveProfile()
        {
            if (Profile.IsEmpty()) return false;
            return Profile.save_profile(Profile.GetProfileFilename()) ? true : false;
        }  //  static public bool SaveProfile()


        //
        //  static public bool NewProfile()
        //
        //  A convenient stub to Profile.NewProfile, returning a boolean value for success or failure.
        //  This method offers the user an opportunity to persist an existing Profile if there are unsaved
        //  edits.
        //
        static public bool NewProfile()
        {

            if (Profile.IsEdited() && !NotifyUnsavedChanges()) return false;

            //  Clear the log before requesting frmGAVPI refresh its UI otherwise the ListBox may remain unpopulated.

            Log.Clear();

            if (Application.OpenForms.OfType<frmGAVPI>().Count() > 0)
                MainForm.RefreshUI(GetStatusString());

            return Profile.NewProfile() ? true : false;

        }  //  static public bool NewProfile()

    }  //  static class GAVPI

}
