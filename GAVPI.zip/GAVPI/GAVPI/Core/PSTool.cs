﻿using System.Windows.Forms;

namespace GAVPI
{
    class PSTool
    {
        public int keyID;
        public string key;
        public string name;
        public Button button;

        public PSTool(int keyID, string key, string name, Button button)
        {
            this.keyID = keyID;
            this.key = key;
            this.name = name;
            this.button = button;
        }
    }
}
